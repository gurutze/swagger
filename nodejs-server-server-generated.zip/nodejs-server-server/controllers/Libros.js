'use strict';

var utils = require('../utils/writer.js');
var Libros = require('../service/LibrosService');

module.exports.addLibros = function addLibros (req, res, next) {
  var body = req.swagger.params['body'].value;
  Libros.addLibros(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteLibros = function deleteLibros (req, res, next) {
  var librosId = req.swagger.params['LibrosId'].value;
  var api_key = req.swagger.params['api_key'].value;
  Libros.deleteLibros(librosId,api_key)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.findLibrosByStatus = function findLibrosByStatus (req, res, next) {
  var status = req.swagger.params['status'].value;
  Libros.findLibrosByStatus(status)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.findLibrosByTags = function findLibrosByTags (req, res, next) {
  var tags = req.swagger.params['tags'].value;
  Libros.findLibrosByTags(tags)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getLibrosById = function getLibrosById (req, res, next) {
  var librosId = req.swagger.params['librosId'].value;
  Libros.getLibrosById(librosId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateLibros = function updateLibros (req, res, next) {
  var body = req.swagger.params['body'].value;
  Libros.updateLibros(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateLibrosWithForm = function updateLibrosWithForm (req, res, next) {
  var librosId = req.swagger.params['librosId'].value;
  var name = req.swagger.params['name'].value;
  var status = req.swagger.params['status'].value;
  Libros.updateLibrosWithForm(librosId,name,status)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.uploadFile = function uploadFile (req, res, next) {
  var petId = req.swagger.params['petId'].value;
  var additionalMetadata = req.swagger.params['additionalMetadata'].value;
  var file = req.swagger.params['file'].value;
  Libros.uploadFile(petId,additionalMetadata,file)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
