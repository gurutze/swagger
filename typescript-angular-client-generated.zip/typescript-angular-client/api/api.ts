export * from './libros.service';
import { LibrosService } from './libros.service';
export * from './store.service';
import { StoreService } from './store.service';
export * from './user.service';
import { UserService } from './user.service';
export const APIS = [LibrosService, StoreService, UserService];
